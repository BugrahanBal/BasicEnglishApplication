package co.example.basicenglish.ui.vocabulary;

public interface RecyclerViewClickListener {
    void onClick(int position1, VocabularyAndSentenceData selectedVocabulary);
}
