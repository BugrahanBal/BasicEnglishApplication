package co.example.basicenglish;


public class GeneralConstants {

    public static final String HOSPITAL = "Hastane";
    public static final String SCHOOL = "Okul";
    public static final String COLOR ="Renkler";
    public static final String BODY = "Vücut";
    public static final String CLOTHES ="Kıyafet";
    public static final String SPORT ="Spor";
    public static final String JOBS ="Meslek";
    public static final String CULINARY = "Mutfak";
    public static final String ART ="Sanat";
    public static final String MUSIC = "Muzik";
    public static final String FOOD = "Yiyecek";
    public static final String DRINK = "İçecek";
    public static final String NUMBER = "Rakamlar";
    public static final String CHORES = "Ev İşleri";
    public static final String TRANSPORTATION = "Ulaşım";
    public static final String NATURE = "Doğa";
    public static final String DISASTER = "Felaket";
    public static final String FAMILY = "Aile";
    public static final String SEASON ="Mevsim";
    public static final String MONTHS ="Aylar";
    public static final String EMOTION = "Hisler";
    public static final String HOBBY ="Hobi";
    public static final String EDUCATION ="Eğitim";
    public static final String ANIMAL ="Hayvan";
    public static final String VEGETABLE ="Sebze";
    public static final String HOUSE ="Konaklama";
    public static final String FRUIT="Meyve";
    public static final String POLITICS="Siyaset";
    public static final String HEALTH ="Sağlık";
    public static final String SHOPPING ="Alışveriş";
    public static final String ADJECTIVE ="Sıfat";
    public static final String COUNTRY ="Ülkeler";
    public static final String CAR ="Araba";

    public static final String GREETING ="Selamlaşma";
    public static final String WARNING ="Uyarmak";
    public static final String AGREEDISAGREE="Fikrine Katılma";
    public static final String GOODBYE = "Vedalaşma";
    public static final String WEATHER ="Hava Durumu";
    public static final String TIME="Zaman";
    public static final String BANK="Banka";
    public static final String RESTAURANT="Restoran";
    public static final String BARBER="Kuaför";
    public static final String MARKET="Market";
    public static final String UNIVERSITY="Okul";
    public static final String CARC="Araç";





















    public static final String SAYFA_BIR_ARR_DATA = "SAYFA_BIR_ARR_DATA";

}
