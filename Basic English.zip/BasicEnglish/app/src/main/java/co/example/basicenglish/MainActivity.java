package co.example.basicenglish;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import co.example.basicenglish.mic.Mic;
import co.example.basicenglish.test.QuizActivity;

public class MainActivity extends AppCompatActivity {

    private View decorView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home,
                R.id.navigation_vocabulary,
                R.id.navigation_sentence,
                R.id.navigation_pronunciation)
                .build();
        // bottom menu idleri dikkat et !!

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

      /*if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }*/




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem menu) {
        switch (menu.getItemId()) {

            case R.id.test:
                Intent testegit =new Intent(getApplicationContext(),QuizActivity.class);
                startActivity(testegit);
                return true;

            case R.id.hakkimizda:
                showAlert("Hakkımızda Açılıyor");
                goToClass(Mic.class);
                return true;

            case R.id.cikis:
                showAlert("Çıkış Yapılıyor");
                finish();
                //System.exit(0);// hayvan gibi kapatıyor ashhafs
                return true;

            default:
                return super.onOptionsItemSelected(menu);
        }
    }

    private <T> void goToClass(Class<T> mClass) { // T ile classı belirtiyoruz
        startActivity(new Intent(getApplicationContext(), mClass));
    }

    public void showAlert(String text) {
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();
    }
}